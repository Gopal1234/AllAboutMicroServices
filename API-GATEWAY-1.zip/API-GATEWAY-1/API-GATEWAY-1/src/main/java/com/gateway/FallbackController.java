package com.gateway;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FallbackController {

    @RequestMapping("/fallback/students")
    public ResponseEntity<String> studentFallback() {
        return ResponseEntity.ok("Student service is currently unavailable. Please try again later.");
    }

    @RequestMapping("/fallback/courses")
    public ResponseEntity<String> courseFallback() {
        return ResponseEntity.ok("Course service is currently unavailable. Please try again later.");
    }
}