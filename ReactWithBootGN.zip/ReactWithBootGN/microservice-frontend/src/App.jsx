import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import Navbar from "./components/Navbar";
import Login from "./components/Login";
import Register from "./components/Register";
import CourseList from "./components/CourseList";
import CourseCreate from "./components/CourseCreate";
import StudentList from "./components/StudentList";

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/courses" element={<CourseList />} />
          <Route path="/courses/create" element={<CourseCreate />} />
          <Route path="/students" element={<StudentList />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
