import { Link } from "react-router-dom";
import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";

export default function Navbar() {
  const { user, logout } = useContext(AuthContext);

  return (
    <nav>
      <Link to="/courses">Courses</Link>
      {user?.roles.includes("ROLE_ADMIN") && <Link to="/courses/create">Create Course</Link>}
      <Link to="/students">Students</Link>
      {!user ? <Link to="/login">Login</Link> : <button onClick={logout}>Logout</button>}
    </nav>
  );
}
