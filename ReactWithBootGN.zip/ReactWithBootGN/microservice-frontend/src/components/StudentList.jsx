import { useEffect, useState } from "react";
import api from "../api/axiosConfig";

export default function StudentList() {
  const [students, setStudents] = useState([]);

  useEffect(() => {
    api.get("/students").then((res) => setStudents(res.data));
  }, []);

  return (
    <div>
      <h2>Students</h2>
      <ul>
        {students.map((s) => (
          <li key={s.id}>{s.name}</li>
        ))}
      </ul>
    </div>
  );
}
