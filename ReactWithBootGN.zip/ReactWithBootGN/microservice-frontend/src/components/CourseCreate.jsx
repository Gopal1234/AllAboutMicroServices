import { useState } from "react";
import api from "../api/axiosConfig";

export default function CourseCreate() {
  const [name, setName] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    await api.post("/courses/create", { name });
    alert("Course created!");
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Create Course</h2>
      <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Course Name" />
      <button type="submit">Create</button>
    </form>
  );
}
